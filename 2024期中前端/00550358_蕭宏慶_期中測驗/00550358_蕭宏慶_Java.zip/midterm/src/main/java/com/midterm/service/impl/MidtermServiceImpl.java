package com.midterm.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.loading.PrivateClassLoader;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.midterm.service.MidtermService;

import springfox.documentation.swagger.web.SwaggerApiListingReader;

@Service
public class MidtermServiceImpl implements MidtermService {
	private static final String Private = null;
	@Autowired
	private DataSource dataSource;

	/**
	 * 範例程式
	 * 
	 * @param demoMap
	 * @return
	 */
	@Override
	public Map<String, Object> demoCode(Map<String, String> demoMap) {
		/* 1. 將前端傳入值取出：使用前端傳入物件的key值，從Map中取得對應value，例如： */
		String id = demoMap.get("id");
		String keyword = demoMap.get("keyword");
		System.err.println("id--->" + id);
		System.err.println("keyword--->" + keyword);

		// 2. 業務邏輯：檢核、題目要求邏輯實作，如需使用DB連線，請參考下列程式碼

		/*
		 * try (Connection conn = dataSource.getConnection(); PreparedStatement pstmt =
		 * conn.prepareStatement(SELECT_CARS_SQL);) { ResultSet rs =
		 * pstmt.executeQuery(); List<Map<String, String>> nameMapList = new
		 * ArrayList<>(); while (rs.next()) { Map<String, String> nameMap = new
		 * HashMap<>(); nameMap.put("NAME",rs.getString("COLUMN_NAME")); //
		 * carMap.put("MANUFACTURER", rs.getString("MANUFACTURER")); //
		 * rs.getString("DB_COLUMN_NAME") // carMap.put("TYPE", rs.getString("TYPE"));
		 * // carMap.put("MIN_PRICE", rs.getString("MIN_PRICE")); // carMap.put("PRICE",
		 * rs.getString("PRICE")); nameMapList.add(nameMap);
		 * System.out.println(nameMap); }
		 * 
		 * } catch (SQLException e) { e.printStackTrace(); }
		 */

		/* 3. 把要回傳給前端的值包裝成Map後return，例如： */
		Map<String, Object> rtnMap = new HashMap<>();
		rtnMap.put("success", true);
		rtnMap.put("returnMessage", "驗證成功");
		rtnMap.put("metro_fee", 100);
		rtnMap.put("pokerA", new ArrayList<>());
		return rtnMap;
	}

	/**
	 * 第一題：發撲克牌
	 * 
	 * @param map
	 * @return
	 */
	@Override
	public Map<String, Object> deal(Map<String, String> map) {
		// TODO Auto-generated method stub

		return null;
	}

	/**
	 * 第二題：證件號碼驗證
	 * 
	 * @param map
	 * @return
	 */
	@Override
	public Map<String, Object> checkId(Map<String, String> map) {
		// TODO Auto-generated method stub
		return null;

	}

	/**
	 * 第二題：證件號碼驗證_加分題
	 * 
	 * @param map
	 * @return
	 */
	@Override
	public Map<String, Object> getRandomId(Map<String, String> map) {
		// TODO Auto-generated method stub
		return null;

	}

	/**
	 * 第三題：Wordle
	 * 
	 * @param map
	 * @return
	 */
	@Override
	public Map<String, Object> wordle(Map<String, String> map) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 第四題：對對碰
	 * 
	 * @param map
	 * @return
	 */
	private String SELECT_NAMES_SQL = "select VOCAB from Student.EX_WORDLE ";
	@Override
	public Map<String, Object> matchingGame(Map<String, String> map) {
		String inputNumString = map.get("num");
		int inputNumInt = Integer.parseInt(inputNumString);
		Map<String, Object> outputMap = new HashMap<>();
		List<String> nameMapList = new ArrayList<>();
		try (Connection conn = dataSource.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(SELECT_NAMES_SQL);
				ResultSet rs = pstmt.executeQuery();) {
			while (rs.next()) {
				nameMapList.add(rs.getString("VOCAB"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Collections.shuffle(nameMapList);
		List<String> slicedArray = nameMapList.subList(0, inputNumInt * inputNumInt / 2);
		// 合併陣列
		slicedArray.addAll(slicedArray);
		Collections.shuffle(slicedArray);
		for (Integer i = 0; i < slicedArray.size(); i++) {
			outputMap.put(i.toString(), slicedArray.get(i));
		}
		return outputMap;
	}

	/**
	 * 第五題：捷運車資計算
	 * 
	 * @param map
	 * @return
	 */
	@Override
	public Map<String, Object> metro(Map<String, String> map) {
		// TODO Auto-generated method stub
		return null;
	}

}
